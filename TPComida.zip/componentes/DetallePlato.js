import { useContext, useEffect, useState } from "react";
import { ContextTPComidas } from "../context/context";
import { Button, View } from "react-native-web";
import { Image } from "react-bootstrap";
import { StyleSheet } from "react-native";
import { useNavigation } from "@react-navigation/native";
import axios from "axios";

function DetallePlato({ route }) {
    const context = useContext(ContextTPComidas);
    const navigation = useNavigation();

    const plato = route.params.plato;

    const [platoEntero, setPlatoEntero] = useState();

    useEffect(() => {
        axios.get(`https://api.spoonacular.com/recipes/${plato.id}/information?includeNutrition=false&apiKey=451ace4e62314779b69da982ba3fb92d`)
        .then(response => {
            let plato = response.data;
            setPlatoEntero(plato);
        });
    }, [])

    const handleClick = () => {
        context.añadirPlato(platoEntero);
        navigation.goBack();
    }

    if(typeof platoEntero === "undefined") return (<div>El plato esta cargando</div>);

    return (
        <View style={{display: "flex", flexDirection:"column", justifyContent: "center", alignItems: "center"}}>
            <View style={styles.container}>
                <Image style={{ width: "100%" }} src={plato.image}></Image>
                <div>Plato Vegano: {(platoEntero.vegan == true) ? "SI" : "NO"}</div>
                <div>Precio: {platoEntero.pricePerServing}</div>
                <Button title="Añadir al menu" onPress={() => handleClick()}></Button>
            </View>
            <h3>{plato.title}</h3>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        width: "50%",
        height: "50%",
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: "Column",
        padding: "2%"
    },
});

export default DetallePlato;