import { useContext, useEffect, useState } from "react";
import { ContextTPComidas } from "../context/context";
import { TextInput } from "react-native";
import axios from "axios";
import { View } from "react-native-web";

function Busqueda() {
    const context = useContext(ContextTPComidas);

    const [busqueda, setBusqueda] = useState("");

    useEffect(() => {

        let terminoBusqueda;
        if (busqueda.length <= 2) terminoBusqueda = "";
        else terminoBusqueda = busqueda;

        axios.get(`https://api.spoonacular.com/recipes/complexSearch?query=${terminoBusqueda}&apiKey=451ace4e62314779b69da982ba3fb92d`)
            .then(response => {
                let platos = response.data.results;
                context.setCarta(platos);
            });
    }, [busqueda]);

    return (
        <View style={{backgroundColor: "green"}}>
            <TextInput placeholder="Inserte un termino de busqueda" onChangeText={text => setBusqueda(text)} />
        </View>
    );
}

export default Busqueda;